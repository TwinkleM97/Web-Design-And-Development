const { default: mongoose } = require("mongoose");

const Order = mongoose.model("Order", {
    name: String,
    phone: String,
    mangojuiceQty: String,
    berryjuiceQty: String,
    applejuiceQty: String,
    subTotal: Number,
    tax: Number,
    totalCost: Number
  });

module.exports = Order