const express = require("express");
const path = require("path");
const mongoose = require("mongoose");

mongoose.connect("mongodb://localhost:27017/final8021Sec2");
var isAdmin = false;

const Order = mongoose.model("Order", {
  name: String,
  phone: String,
  mangoJuices: Number,
  berryJuices: Number,
  appleJuices: Number,
  subTotal: Number,
  tax: Number,
  totalCost: Number,
});

const Admin = mongoose.model("Admin", {
  uname: String,
  pass: String,
});

var myApp = express();

myApp.set("views", path.join(__dirname, "views"));
myApp.use(express.static(path.join(__dirname, "public")));
myApp.set("view engine", "ejs");
myApp.use(express.urlencoded({ extended: false }));

function checkValidUser(req, res, next) {
  if (req.url === '/allOrders' && isAdmin === true) {
    res.redirect('/login');
  } else {
    next();
  }
}

function validateOrderInput(req) {
  let errors = [];
  const { name, phone, mangojuiceQty, berryjuiceQty, applejuiceQty } = req.body;
  const namePattern = /^[A-Za-z]+(?:[ '-][A-Za-z]+)*$/;
  const phonePattern = /^\d{3}-\d{3}-\d{4}$/; // phone number follows xxx-xxx-xxxx format

  // Validate name
  if (!name || name.length < 5 || !namePattern.test(name)) {
    errors.push('Invalid name. Name must be at least 5 characters and only contain alphabets and certain special characters ( - and \')');
  }

  // Validate phone number
  if (!phone || !phonePattern.test(phone)) {
    errors.push('Invalid phone number. Please use the format xxx-xxx-xxxx.');
  }

  // Validate juice quantities
  const mangoQty = parseInt(mangojuiceQty, 10);
  const berryQty = parseInt(berryjuiceQty, 10);
  const appleQty = parseInt(applejuiceQty, 10);

  if (isNaN(mangoQty) || isNaN(berryQty) || isNaN(appleQty)) {
    errors.push('All quantity fields must be valid numbers.');
  } else if (mangoQty < 0 || berryQty < 0 || appleQty < 0) {
    errors.push('Quantities cannot be negative.');
  } else if (mangoQty === 0 && berryQty === 0 && appleQty === 0) {
    errors.push('Please select at least one quantity to proceed.');
  }

  return errors;
}

async function onSubmit(req, res) {
  try {
    const errors = validateOrderInput(req);
    if (errors.length > 0) {
      return res.render('orders', { errors });
    }

    const { name, phone, mangojuiceQty, berryjuiceQty, applejuiceQty } = req.body;

    // Convert quantities to numbers
    const mangoQty = parseInt(mangojuiceQty, 10) || 0;
    const berryQty = parseInt(berryjuiceQty, 10) || 0;
    const appleQty = parseInt(applejuiceQty, 10) || 0;

    // Calculate totals
    const mangoPrice = 2.39;
    const berryPrice = 1.89;
    const applePrice = 2.29;

    const subTotal = (mangoQty * mangoPrice) + (berryQty * berryPrice) + (appleQty * applePrice);
    const tax = subTotal * 0.13; //13% tax rate
    const totalCost = subTotal + tax;

    // Create new order
    const order = new Order({
      name,
      phone,
      mangoJuices: mangoQty,
      berryJuices: berryQty,
      appleJuices: appleQty,
      subTotal,
      tax,
      totalCost
    });

    await order.save();
    res.render('orders', { orderResult: order });
  } catch (error) {
    console.error(error);
    res.render('orders', { errors: ['Error saving order'] });
  }
}

async function onLogin(req, res) {
  let errors = [];
  const { uname, pass } = req.body;

  if (!uname) {
    errors.push('Username is required.');
  }
  if (!pass) {
    errors.push('Password is required.');
  }

  if (errors.length > 0) {
    return res.render('login', { errors });
  }

  try {
    const login = await Admin.findOne({ uname, pass }).exec();
    if (login) {
      isAdmin = false;
      res.redirect("/allOrders");
    } else {
      res.render('login', { errors: ['Invalid credentials.'] });
    }
  } catch (error) {
    console.error(error);
    res.render('login', { errors: ['Error during login.'] });
  }
}

myApp.set("views", path.join(__dirname, "views"));
myApp.use(express.static(path.join(__dirname, "public")));
myApp.set("view engine", "ejs");
myApp.use(express.urlencoded({ extended: false }));

// Routes
myApp.get("/", (req, res) => {
  res.redirect('/orders');
});

myApp.get("/orders", (req, res) => {
  res.render('orders', { errors: [], formData: {} });
});

myApp.post("/orders", (req, res) => {
  onSubmit(req, res);
});

myApp.get('/allOrders', checkValidUser, async (req, res) => {
  try {
    const allOrdersResult = await Order.find().exec();
    res.render('allOrders', { allOrdersResult });
  } catch (error) {
    console.error(error);
    res.render('allOrders', { errors: ['Error fetching orders.'] });
  }
});

myApp.get('/login', (req, res) => {
  res.render('login', { errors: [] });
});

myApp.post('/login', (req, res) => {
  onLogin(req, res);
});


myApp.get('/logout', (req, res) => {
  isAdmin = false;
  res.render('logout-success'); 
});


myApp.get('/delete/:id', async (req, res) => {
  try {
    const id = req.params.id;
    await Order.findByIdAndDelete(id).exec();
    res.render('successPage', {
      status: 'Deleted successfully',
      backLink: '/allOrders'
    });
  } catch (error) {
    console.error(error);
    res.render('successPage', {
      status: 'Something went wrong. Please try again.',
      backLink: '/allOrders'
    });
  }
});

// Setup the database
myApp.get("/setup", async (req, res) => {
  try {
    const adminData = [{ uname: "admin", pass: "admin" }];
    await Admin.collection.insertMany(adminData);

    const firstNames = ["John", "Alana", "Jane", "Will", "Tom", "Leon", "Jack", "Kris", "Lenny", "Lucas"];
    const lastNames = ["May", "Riley", "Rees", "Smith", "Walker", "Allen", "Hill", "Byrne", "Murray", "Perry"];

    let ordersData = [];

    for (let i = 0; i < 10; i++) {
      const tempName = `${firstNames[Math.floor(Math.random() * 10)]} ${lastNames[Math.floor(Math.random() * 10)]}`;
      const tempOrder = {
        name: tempName,
        phone: `${Math.floor(Math.random() * 1000)}-${Math.floor(Math.random() * 1000)}-${Math.floor(Math.random() * 10000)}`,
        mangoJuices: Math.floor(Math.random() * 10),
        berryJuices: Math.floor(Math.random() * 10),
        appleJuices: Math.floor(Math.random() * 10),
      };
      ordersData.push(tempOrder);
    }

    await Order.collection.insertMany(ordersData);
    res.send("Database setup complete. You can now proceed.");
  } catch (error) {
    console.error(error);
    res.send("Error setting up database.");
  }
});

// Start the server
myApp.listen(8080, () => {
  console.log("Server started at http://localhost:8080");
});
