$(document).ready(function(){
    $(".more-info-btn").click(function(){
        var target = $(this).data("target");
        $(target).toggle();
    });
});

$(document).ready(function(){
    $('#order-form').submit(function(event){
        event.preventDefault();
        var name = $('#name').val();
        var nameRegex = /^[a-zA-Z\s]+$/;

        if (name === "" || !nameRegex.test(name)) {
            alert("Please enter a valid name that is not empty and does not contain numbers");
            return;
        }
        
        var phone = $('#phone').val();
        var phoneRegex = /^\(\d{3}\)-\d{3}-\d{4}$/;
        
        if (!phoneRegex.test(phone)) {
            alert("Invalid phone number. Please enter a valid phone number in the format xxx-xxx-xxxx");
            return;
        }
        
        var dressQty = parseInt($('#dress').val()) || 0;
        var jacketQty = parseInt($('#jacket').val()) || 0;
        var shirtQty = parseInt($('#shirt').val()) || 0;

        if (dressQty === 0 && jacketQty === 0 && shirtQty === 0) {
            alert("You must buy at least one item.");
            return;
        }

        var dressTotal = dressQty * 35.00;
        var jacketTotal = jacketQty * 75.00;
        var shirtTotal = shirtQty * 15.00;
        
        var subtotal = dressTotal + jacketTotal + shirtTotal;
        alert(subtotal);

        var tax = subtotal * 0.13; 
        var total = subtotal + tax;
        
       
        var invoiceDetails1 = "<table class='invoice-table1'>"; 
        invoiceDetails1 += "<h2 align='center'>Invoice</h2>";
        invoiceDetails1 += "<tr><td><b>Customer Name:</b></td><td>" + name + "</td></tr>";
        invoiceDetails1 += "<tr><td><b>Customer Phone Number:</b></td><td>" + phone + "</td></tr>";
        invoiceDetails1 += "</table>"; 
        invoiceDetails1 += "<br></br>"; 

        var invoiceDetails = "<table class='invoice-table'>"; 
        invoiceDetails += "<tr><th>Item</th><th>Quantity</th><th>Price</th></tr>"; 

        if (dressQty > 0) {
          invoiceDetails += "<tr><td>Dress</td><td>" + dressQty + "</td><td>$" + dressTotal.toFixed(2) + "</td></tr>";
        }
        if (jacketQty > 0) {
          invoiceDetails += "<tr><td>Jacket</td><td>" + jacketQty + "</td><td>$" + jacketTotal.toFixed(2) + "</td></tr>";
        }
        if (shirtQty > 0) {
          invoiceDetails += "<tr><td>Shirt</td><td>" + shirtQty + "</td><td>$" + shirtTotal.toFixed(2) + "</td></tr>";
        }

        invoiceDetails += "<tr><td>Subtotal</td><td></td><td>$" + subtotal.toFixed(2) + "</td></tr>";
        invoiceDetails += "<tr><td>Tax</td><td></td><td>$" + tax.toFixed(2) + "</td></tr>";
        invoiceDetails += "<tr><td>Total</td><td></td><td>$" + total.toFixed(2) + "</td></tr>";

        invoiceDetails += "</table>"; 

        // Display the invoice
        var invoiceContainer = document.getElementById('invoice');
        invoiceContainer.innerHTML = invoiceDetails1 + invoiceDetails;

        $('#invoice').show();
    });
});
