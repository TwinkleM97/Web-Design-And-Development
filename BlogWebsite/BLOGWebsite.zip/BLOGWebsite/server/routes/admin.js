const express = require('express');
const router = express.Router();
const Post = require('../models/Post');
const User = require('../models/User');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const fs = require('fs');
const path = require('path');
const multer = require("multer");

const adminLayout = '../views/layouts/admin';
const jwtSecret = process.env.JWT_SECRET;

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, '/uploads/'));
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + "-" + file.originalname);
  },
});

const upload = multer({ storage: storage });

const authMiddleware = (req, res, next) => {
  const token = req.cookies.token;

  if (!token) {
    return res.status(401).json({ message: 'Unauthorized' });
  }

  try {
    const decoded = jwt.verify(token, jwtSecret);
    req.userId = decoded.userId;
    next();
  } catch (error) {
    res.status(401).json({ message: 'Unauthorized' });
  }
};

// Admin Login Page
router.get('/admin', async (req, res) => {
  try {
    const locals = {
      title: "Admin",
      description: "Simple Blog Website"
    };
    res.render('admin/index', { locals, layout: adminLayout });
  } catch (error) {
    console.log(error);
  }
});

// Admin Check Login
router.post('/admin', async (req, res) => {
  try {
    const { username, password } = req.body;
    const user = await User.findOne({ username });

    if (!user || !(await bcrypt.compare(password, user.password))) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    const token = jwt.sign({ userId: user._id }, jwtSecret);
    res.cookie('token', token, { httpOnly: true });
    res.redirect('/login-success'); // Redirect to the success page
  } catch (error) {
    console.log(error);
  }
});
// Admin Dashboard
router.get('/dashboard', authMiddleware, async (req, res) => {
  try {
    const locals = {
      title: 'Dashboard',
      description: 'Simple Blog Website'
    };
    const data = await Post.find();
    res.render('admin/dashboard', {
      locals,
      data,
      layout: adminLayout
    });
  } catch (error) {
    console.log(error);
  }
});

// Create New Post Form
router.get('/add-post', authMiddleware, async (req, res) => {
  try {
    const locals = {
      title: 'Add Post',
      description: 'Simple Blog Website'
    };
    res.render('admin/add-post', {
      locals,
      layout: adminLayout
    });
  } catch (error) {
    console.log(error);
  }
});

// Create New Post
router.post('/add-post', authMiddleware, upload.single('image'), async (req, res) => {
  try {
    const obj = {
      title: req.body.title,
      body: req.body.body,
      img: {
        data: fs.readFileSync(path.join(__dirname, '/uploads/', req.file.filename)),
        contentType: 'image/png'
      }
    };
    await Post.create(obj);
    res.redirect('/add-post-success'); // Redirect to success message
  } catch (error) {
    console.log(error);
  }
});

// Edit Post Form
router.get('/edit-post/:id', authMiddleware, async (req, res) => {
  try {
    const locals = {
      title: "Edit Post",
      description: "Edit your post"
    };
    const data = await Post.findOne({ _id: req.params.id });
    res.render('admin/edit-post', {
      locals,
      data,
      layout: adminLayout
    });
  } catch (error) {
    console.log(error);
  }
});

// Update Post
router.put('/edit-post/:id', authMiddleware, upload.single('image'), async (req, res) => {
  try {
    const updateData = {
      title: req.body.title,
      body: req.body.body,
      updatedAt: Date.now()
    };
    
    if (req.file) {
      updateData.img = {
        data: fs.readFileSync(path.join(__dirname, '/uploads/', req.file.filename)),
        contentType: 'image/png'
      };
    }
    
    await Post.findByIdAndUpdate(req.params.id, updateData);
    res.redirect('/edit-post-success'); // Redirect to success message
  } catch (error) {
    console.log(error);
  }
});

// Delete Post
router.delete('/delete-post/:id', authMiddleware, async (req, res) => {
  try {
    await Post.deleteOne({ _id: req.params.id });
    res.redirect('/delete-post-success'); // Redirect to success message
  } catch (error) {
    console.log(error);
  }
});

// Register User
router.post('/register', async (req, res) => {
  try {
    const { username, password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);

    try {
      const user = await User.create({ username, password: hashedPassword });
      // Redirect to registration completed page
      res.redirect('/registration-completed');
    } catch (error) {
      if (error.code === 11000) {
        res.status(409).json({ message: 'User already in use' });
      } else {
        res.status(500).json({ message: 'Internal server error' });
      }
    }
  } catch (error) {
    console.log(error);
  }
});
// Logout
router.get('/logout', (req, res) => {
  res.clearCookie('token');
  res.redirect('/logout-success'); // Redirect to a page that shows the success message
});
// Admin Login Success Page
router.get('/login-success', authMiddleware, (req, res) => {
  res.send(`
    <html>
      <head>
        <meta http-equiv="refresh" content="2;url=/dashboard" />
      </head>
      <body>
        <h1>Hello Admin</h1>
        <p>Welcome to the dashboard. You will be redirected shortly...</p>
      </body>
    </html>
  `);
});

// Logout Page
router.get('/logout-success', (req, res) => {
  res.send(`
    <html>
      <head>
        <meta http-equiv="refresh" content="2;url=/" />
      </head>
      <body>
        <h1>Logout Successful</h1>
        <p>You will be redirected to the home page in a moment...</p>
      </body>
    </html>
  `);
});

router.get('/add-post-success', (req, res) => {
  res.send(`
    <html>
      <head>
        <meta http-equiv="refresh" content="2;url=/dashboard" />
      </head>
      <body>
        <h1>Post Added Successfully</h1>
        <p>You will be redirected to the dashboard in a moment...</p>
      </body>
    </html>
  `);
});

router.get('/edit-post-success', (req, res) => {
  res.send(`
    <html>
      <head>
        <meta http-equiv="refresh" content="2;url=/dashboard" />
      </head>
      <body>
        <h1>Post Updated Successfully</h1>
        <p>You will be redirected to the dashboard in a moment...</p>
      </body>
    </html>
  `);
});

router.get('/delete-post-success', (req, res) => {
  res.send(`
    <html>
      <head>
        <meta http-equiv="refresh" content="2;url=/dashboard" />
      </head>
      <body>
        <h1>Post Deleted Successfully</h1>
        <p>You will be redirected to the dashboard in a moment...</p>
      </body>
    </html>
  `);
});
router.get('/registration-completed', (req, res) => {
  res.send(`
    <html>
      <head>
        <meta http-equiv="refresh" content="2;url=/admin" />
      </head>
      <body>
        <h1>Registration Completed!</h1>
        <p>You will be redirected to the login page in a moment...</p>
      </body>
    </html>
  `);
});

module.exports = router;
